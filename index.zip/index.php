<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="An awesome single page portfolio html template. You can easily design your protfolio website using this template">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Cuda - An awesome single page portfolio html template</title>
    <link rel="shortcut icon" type="image/x-icon" href="resours/img/favicon.png">
    <!-- GOOGLE FONTS -->
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:wght@300;400;600;700" rel="stylesheet">
    <!-- FONT AWESOME -->
    <script src="https://kit.fontawesome.com/837850c3ce.js" crossorigin="anonymous"></script>
    <!-- VANDERS FILES -->
    <link rel="stylesheet" href="vanders/css/normalize.css">
    <link rel="stylesheet" href="vanders/css/gird.css">
    <!-- RESOURS FILES -->
    <link rel="stylesheet" href="resours/css/style.css">
    <link rel="stylesheet" href="resours/css/responsive.css">
    
</head>
<body>
    <!--START HEADER SECTION-->
       <header id="home">
           <nav>
               <div class="row">
                   <a href="#home">
                       <img src="resours/img/logo.png" alt="" class="logo">
                   </a>
                   <ul class="main-nav">
                       <li class="active"><a href="#home">Home</a></li>
                       <li><a href="#service">service</a></li>
                       <li><a href="#team">TEAM</a></li>
                       <li><a href="#skill">SKILL</a></li>
                       <li><a href="#protfolio">PROTFOLIO</a></li>
                       <li><a href="#testimonial">testimonial</a></li>
                       <li><a href="#contact">CONTACT</a></li>
                   </ul>
                   <div class="mobile-manu">
                       <span style="color: #fff;" onclick="openNav()">&#9776;</span>
                       <div id="myNav" class="overlay">
                       <a href="javascript:void(0)" onclick="closeNav()" class="closebtn">&times;</a>
                           <div class="overlay-content">
                               <a onclick="closeNav" href="#home">HOME</a>
                               <a onclick="closeNav" href="#service">SERVICE</a>   
                               <a onclick="closeNav" href="#team">TEAM</a>   
                               <a onclick="closeNav" href="#skill">SKILL</a>  
                               <a onclick="closeNav" href="#protfolio">PROTFOLIO</a>   
                               <a onclick="closeNav" href="#testimonial">TESTIMONIAL</a>    
                               <a onclick="closeNav" href="#contact">CONTACT</a>    
                           </div>
                       </div>
                   </div>
               </div>
           </nav>
           <div class="row">
               <div class="hero-text-box">
                   <h1>Hi there! We are the new kids on the block and we build awesome websites and mobile apps.</h1>
                   <a href="#contact" class="btn btn-hero">Work with Us!</a>
               </div>
               
           </div>
       </header>
    <!--END HEADER SECTION-->
    
    
     <!--START SERVICES SECTION-->
     <section class="services-section clearfix js--services-section" id="service">
         <div class="row">
             <h2>services we provide</h2>
                 <p class="little-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quisquam sapiente neque eligendi ipsa dicta voluptatibus sint temporibus sequi eveniet!</p>
         </div>
         <div class="row">
                 <div class="col span_1_of_4 box">
                     <img src="resours/img/flag.png" alt="flag" class="services-icons">
                     <h3>BRANDING</h3>
                     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. </p>
                 </div>
             
                 <div class="col span_1_of_4 box">
                     <img src="resours/img/crayon.png" alt="crayon" class="services-icons">
                     <h3>DESIGN</h3>
                     <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem Eveniet earum sequi!</p>
                 </div>

             
                 <div class="col span_1_of_4 box">
                     <img src="resours/img/gears.png" alt="gears" class="services-icons">
                     <h3>DEVELOPMENT</h3>
                     <p>At vero eos et accusamus et iusto odio dignissimos qui blanditiis praesentium.</p>
                 </div>

            
                 <div class="col span_1_of_4 box">
                     <img src="resours/img/rocket.png" alt="rocket" class="services-icons">
                     <h3>RACKET SCIENCE</h3>
                     <p>Et harum quidem rerum est et expedita distinctio. Nam libero tempore.</p>
                 </div>     
         </div>
     </section>
     <!--END SERVICES SECTION-->
    
    
     <!--START TEAM SECTION-->
     <section class="team-section clearfix" id="team">
         <div class="row">
             <h2>meat your beautiful team</h2>
             <p class="little-description">We are a small team of designers and developers, who help brands with big ideas.
</p>
         </div>
         <div class="row">
            <div class="col span_1_of_4 box">
                 <img src="resours/img/1.jpg" alt="" class="team-member">
                 <h3>ANNY HATHAWAY</h3>
                 <span class="rol">CEO/ Marketing Guru</span>
                 <p>Lorem ipsum dolor sit amet, 
                    consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore.</p>
                 <div class="social-link">
                     <ul>
                         <li><a href="https://www.facebook.com"><i class="fab fa-facebook-f"></i></a></li>
                         <li><a href="https://www.twitter.com"><i class="fab fa-twitter"></i></a></li>
                         <li><a href="https://www.linkedin.com"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                     </ul>
                 </div>
            </div> 
            
            <div class="col span_1_of_4 box">
                 <img src="resours/img/2.jpg" alt="" class="team-member">
                 <h3>KATE UPTON</h3>
                 <span class="rol">Creative Director</span>
                 <p>Duis aute irure dolor in in voluptate velit esse cillum dolore fugiat nulla pariatur. Excepteur sint occaecat non diam proident.</p>
                 <div class="social-link">
                     <ul>
                         <li><a href="https://www.twitter.com"><i class="fab fa-twitter"></i></a></li>
                         <li><a href="https://www.linkedin.com"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                     </ul>
                 </div>
            </div> 
            
            <div class="col span_1_of_4 box">
                 <img src="resours/img/3.jpg" alt="" class="team-member">
                 <h3>Olivia woilde</h3>
                 <span class="rol">Lead Desiner</span>
                 <p>Nemo enim ipsam voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
                 <div class="social-link">
                     <ul>
                         <li><a href="https://www.facebook.com"><i class="fab fa-facebook-f"></i></a></li>
                         <li><a href="https://www.twitter.com"><i class="fab fa-twitter"></i></a></li>
                         <li><a href="https://www.linkedin.com"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                     </ul>
                 </div>
            </div> 
            
            <div class="col span_1_of_4 box">
                 <img src="resours/img/4.jpg" alt="" class="team-member">
                 <h3>ASHLEY GREENE</h3>
                 <span class="rol">SEO/ Developer</span>
                 <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
                 <div class="social-link">
                     <ul>
                        <li><a href="https://www.facebook.com"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="https://www.twitter.com"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fas fa-envelope"></i></a></li>
                     </ul>
                 </div>
            </div> 
         </div>
     </section>
     <!--END TEAM SECTION-->

   
   
    <!--START SKILL SECTION-->
    <section class="skill-section clearfix" id="skill">
        <div class="row">
                <h2>WI GOT SKILLS!</h2>
                <P class="little-description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod 
                tempor incididunt ut labore et dolore magna aliqua.</P>
            <div class="row">   
                <div class="col span_1_of_4 box">                
                    <svg class="radial-progress web-design" data-percentage="90" viewBox="0 0 80 80">
                      <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                      <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                      <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">90%</text>
                    </svg>
                
                    <h3>WEB DESIGN</h3>
                </div>
                
                <div class="col span_1_of_4 box">
                    <svg class="radial-progress html-css" data-percentage="75" viewBox="0 0 80 80">
                      <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                      <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                      <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">75%</text>
                    </svg>
                    <h3>HTML / CSS</h3>
                </div>
                
                <div class="col span_1_of_4 box">
                    <svg class="radial-progress graphic-design" data-percentage="70" viewBox="0 0 80 80">
                      <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                      <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                      <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">70%</text>
                    </svg>
                    <h3>GRAPHIC DESIGN</h3>
                </div>
                
                <div class="col span_1_of_4 box">
                    <svg class="radial-progress ui-ux" data-percentage="85" viewBox="0 0 80 80">
                         <circle class="incomplete" cx="40" cy="40" r="35"></circle>
                         <circle class="complete" cx="40" cy="40" r="35" style="stroke-dashoffset: 39.58406743523136;"></circle>
                         <text class="percentage" x="50%" y="57%" transform="matrix(0, 1, -1, 0, 80, 0)">85%</text>
                    </svg>
                    <h3>UI / UX</h3>
                </div>
            </div> 
        </div>
    </section>
    <!--END SKILL SECTION-->
   
   
   <!--START PROTFOLIO SECTION-->
     <section class="protfolio-section clearfix" id="protfolio">
         <div class="row">
            <h2>UOR PROTFOLIO</h2>
            <p class="little-description">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet consectetur, adipisci velit, sed quia non numquam</p>
             
         </div>
         <div class="row">
             <div class="protfolio-filter">
                 <button type="button" data-filter="all">ALL</button>
                 <button type="button" data-filter=".web">WEB</button>
                 <button type="button" data-filter=".apps">APPS</button>
                 <button type="button" data-filter=".icons">ICONS</button>
             </div>
         </div>
         <div class="row container">
             <div class="col span_1_of_2 mix apps box">
                 <img src="resours/img/portfolio1.png" alt="Isometric Perspective Mock-Up" class="frotfolio-image">
                 <h4>Isometric Perspective Mock-Up</h4>
             </div>
             <div class="col span_1_of_2 mix apps web box">
                 <img src="resours/img/portfolio2.png" alt="Time Zone App UI" class="frotfolio-image">
                 <h4>Time Zone App UI</h4>
             </div>
             <div class="col span_1_of_2 mix icons box">
                 <img src="resours/img/portfolio3.png" alt="Viro MePlayers UI" class="frotfolio-image">
                 <h4>Viro Media Players UI</h4>
             </div>
             <div class="col span_1_of_2 mix icons web apps box">
                 <img src="resours/img/portfolio4.png" alt="Blog / Magazine Flat UI Kit" class="frotfolio-image">
                 <h4>Blog / Magazine Flat UI Kit</h4>
             </div>
         </div>
         
         <!--HIDDEN LOAD MORE BUTTON
         <div class="row">
             <a href="" class="btn btn-load-more">LOAD MORE PROJECT</a>
         </div>
         -->
     </section>
   <!--END PROTFOLIO SECTION-->
   
   
   <!--START TESTIMONIAL SECTION-->
   <section class="testimonial-section clearfix" id="testimonial">
       <div class="row">
          <h2>WHAT POEPLE SAY ABOUT US</h2>
          <p class="little-description">Our clients love us!</p>
           
       </div>
       <div class="row">
           <div class="col span_1_of_2 box">
              <div class="client-photo">
                  <img src="resours/img/1.jpg" alt="client-photo">
              </div>
              <div class="client-review">
                  <p>“Nullam dapibus blandit orci, viverra gravida dui lobortis eget. Maecenas fringilla urna eu nisl.”</p>
                  <h3>CHANEL IMAN</h3>
                  <span class="rol">CEO of Pinterest</span>
              </div>
           </div>
           
           <div class="col span_1_of_2 box">
              <div class="client-photo">
                  <img src="resours/img/2.jpg" alt="client-photo">
              </div>
              <div class="client-review">
                  <p>“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.”</p>
                  <h3>ADRIANA LIMA</h3>
                  <span class="rol">Founder of Instagram</span>
              </div>
           </div>
           
           <div class="col span_1_of_2 box">
              <div class="client-photo">
                  <img src="resours/img/3.jpg" alt="client-photo">
              </div>
              <div class="client-review">
                  <p>“Vivamus luctus urna sed urna ultricies ac tempor dui sagittis. In condimentum facilisis porta.”</p>
                  <h3>ANNE HATHAWAY</h3>
                  <span class="rol">Lead Designer at Behance</span>
              </div>
           </div>
           
           <div class="col span_1_of_2 box">
              <div class="client-photo">
                  <img src="resours/img/4.jpg" alt="client-photo">
              </div>
              <div class="client-review">
                  <p>“Phasellus non purus vel arcu tempor commodo. Fusce semper, purus vel luctus molestie.”</p>
                  <h3>EMMA STONE</h3>
                  <span class="rol">Co-Founder of Shazam</span>
              </div>
           </div>
       </div>
   </section>
   <!--END TESTIMONIA SECTION-->
   
   
   <!--START CONTACT SECTION-->
   <section class="contact-section" id="contact">
       <div class="row">
           <h2>GET IN TOUCH</h2>
           <p class="little-description">1600 Pennsylvania Ave NW, Washington, DC 20500, United States of America. Tel: (202) 456-1111</p>
       </div>
       <div class="row">
           <form action="https://formspree.io/mehedi244460@gmail.com" method="post">
               <div class="row">
                   <div class="col span_1_of_2">
                       <input type="text" name="Name" placeholder="Your Name *" required>
                   </div>
                   <div class="col span_1_of_2">
                       <input type="email" name="Email" placeholder="Your Email *" required>
                   </div>
               </div>
               <div class="row">
                   <textarea name="Message" cols="30" rows="8" placeholder="Your Message *" required></textarea>
               </div>
               <div class="row">
                    <input type="submit" value="SENT MESSAGE" class="btn btn-submit">
               </div>
           </form>
       </div>
   </section>
   <!--END CONTACT SECTION-->
   
 
   <!--START FOOTER SECTION-->
    <div class="footer-section">
        <div class="row">
            <ul>
                <li><a href="#">Facebook</a></li>
                <li><a href="#">Twitter</a></li>
                <li><a href="#">Google+</a></li>
                <li><a href="#">LinkedIn</a></li>
                <li><a href="#">Bhance</a></li>
                <li><a href="#">Dribbble</a></li>
                <li><a href="#">GitHub</a></li>
            </ul>
        </div>
    </div>
     <!--END FOOTER SECTION-->
   
   
    <!--- JS SCRIPT -->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="vanders/js/html5shiv.min.js"></script>
    <script src="vanders/js/respond.min.js"></script>
    <script src="vanders/js/selectivizr.min.js"></script>
    <script src="vanders/js/jquery.waypoints.min.js"></script>
    <script src="vanders/js/mixitup.min.js"></script>
    <script src="resours/js/main.js"></script>
</body>
</html>